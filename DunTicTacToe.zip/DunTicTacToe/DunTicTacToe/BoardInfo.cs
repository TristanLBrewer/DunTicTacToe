﻿using System;

namespace DunTicTacToe
{
    public class BoardInfo
    {
        protected int turns = 0;
        protected int Player1WinTally = 0, Player2WinTally = 0, DrawTally = 0;
        public char playerTeam = ' ';

        //Bool introduced to prevent bug where pressing enter on load switches between players.
        protected bool MoveWasSuccessful = false;

        //Char array, stores player input.
        public char[] BoardArray =
        {
            '1', '2', '3', '4', '5', '6', '7', '8', '9'
        };

        //Draws the grid. (Lines: https://en.wikipedia.org/wiki/Box-drawing_character).
        protected void DrawBoard()
        {
            Console.Clear();
            Console.WriteLine("\n   Tic Tac Toe:\n");
            Console.WriteLine("    ┌───┬───┬───┐");
            Console.WriteLine("    │ {0} │ {1} │ {2} │", BoardArray[6], BoardArray[7], BoardArray[8]);
            Console.WriteLine("    ├───┼───┼───┤");
            Console.WriteLine("    │ {0} │ {1} │ {2} │", BoardArray[3], BoardArray[4], BoardArray[5]);
            Console.WriteLine("    ├───┼───┼───┤");
            Console.WriteLine("    │ {0} │ {1} │ {2} │", BoardArray[0], BoardArray[1], BoardArray[2]);
            Console.WriteLine("    └───┴───┴───┘");
            Console.WriteLine("\n   Win Tally:");
            Console.WriteLine("   Player 1: {0}", Player1WinTally);
            Console.WriteLine("   Player 2: {0}", Player2WinTally);
            Console.WriteLine("   Draw:     {0}", DrawTally);
        }

        //Assigns team symbols to players.
        public void TeamAssignment(int player)
        {
            if (player == 1)
            {
                playerTeam = 'X';
            }
            else if (player == 2)
            {
                playerTeam = 'O';
            }
        }

        //Sets the board numbers to the player symbol.
        public void SymbolAssignment(int input)
        {
            switch (input)
            {
                case 1: BoardArray[0] = playerTeam; break;
                case 2: BoardArray[1] = playerTeam; break;
                case 3: BoardArray[2] = playerTeam; break;
                case 4: BoardArray[3] = playerTeam; break;
                case 5: BoardArray[4] = playerTeam; break;
                case 6: BoardArray[5] = playerTeam; break;
                case 7: BoardArray[6] = playerTeam; break;
                case 8: BoardArray[7] = playerTeam; break;
                case 9: BoardArray[8] = playerTeam; break;
            }
        }

        //Resets board.
        public void BoardReset()
        {
            char[] BoardResetArray =
            {
                '1', '2', '3', '4', '5', '6', '7', '8', '9'
            };

            BoardArray = BoardResetArray;
            DrawBoard();
            turns = 0;
        }
    }
}