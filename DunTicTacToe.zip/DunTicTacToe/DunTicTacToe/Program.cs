﻿namespace DunTicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            //Tests were learned here: https://docs.microsoft.com/en-us/visualstudio/test/walkthrough-creating-and-running-unit-tests-for-managed-code?view=vs-2022

            //Begins game (Starts do/while).
            Turns turnsObj = new Turns();
            turnsObj.TakeTurns();
        }
    }
}