﻿using System;

namespace DunTicTacToe
{
    class Turns : BoardInfo
    {
        int player = 1;
        int input = 0;
        bool inputCorrect = true;

        //Begins turns.
        public void TakeTurns()
        {
            //Infinite loop.
            do
            {
                WinChecker winChecker = new WinChecker(BoardArray, turns);

                SwitchPlayers();

                //Assigns moves/Sets up game.
                SymbolAssignment(input);
                DrawBoard();

                //Checks game status.
                if(winChecker.Win() == true)
                {
                    if(player == 1)
                    {
                        Player2WinTally++;
                    }
                    else if(player == 2)
                    {
                        Player1WinTally++;
                    }
                    Console.WriteLine("\n   Press any key to play again.");
                    Console.ReadKey();
                    BoardReset();
                }
                else if(winChecker.Draw() == true)
                {
                    DrawTally++;
                    Console.ReadKey();
                    BoardReset();
                }

                ReceiveInput();

            } while (true);
        }

        //Switches players.
        public void SwitchPlayers()
        {
            if (input != 0 && MoveWasSuccessful == true)
            {
                //This method of alternating turns also means whoever loses the game will go first in the next game.
                if (player == 2)
                {
                    player = 1;
                    TeamAssignment(player);
                }
                else if (player == 1)
                {
                    player = 2;
                    TeamAssignment(player);
                }
            }
        }

        //Receives the input.
        void ReceiveInput()
        {
            do
            {
                //set input to 0 here. Stops bug where input would carry over from previous game if 'enter' is pressed on move 1.
                input = 0;
                Console.WriteLine("\n   Ready Player {0}: It's your move!", player);
                try
                {
                    input = Convert.ToInt32(Console.ReadLine());
                }
                catch
                {
                    MoveWasSuccessful = false;
                    DrawBoard();
                    Console.WriteLine("\n   Invalid Input. Enter a number!");
                }
                CheckInput();
            } while (!inputCorrect);
        }

        //Validates the input.
        public void CheckInput()
        {
            try
            {
                int testInt = (int)Char.GetNumericValue(BoardArray[input - 1]);
                if (testInt == input && input != 0)
                {
                    inputCorrect = true;
                    MoveWasSuccessful = true;
                    testInt = 0;
                    turns++;
                }
                else
                {
                    DrawBoard();
                    Console.WriteLine("\n   Invalid Move.  \n   Please enter a valid number!");
                    inputCorrect = false;
                    MoveWasSuccessful = false;
                }
            }
            catch
            {
                DrawBoard();
                Console.WriteLine("\n   How have you messed this up?\n   Please enter a valid number!");
            }
        }
    }
}