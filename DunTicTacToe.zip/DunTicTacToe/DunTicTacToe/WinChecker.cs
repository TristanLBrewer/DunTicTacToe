﻿using System;

namespace DunTicTacToe
{
    public class WinChecker : BoardInfo
    {
        public WinChecker(char[] arr, int _turns)
        {
            BoardArray = arr;
            turns = _turns;
        }

        //Checks for a winner.
        public bool Win()
        {
            //Array of the two team options.
            char[] playerTeams = { 'X', 'O' };

            //Foreach loop checking all 8 win conditions for each team.
            foreach (char playerTeam in playerTeams)
            {
                if (((BoardArray[0] == playerTeam) && (BoardArray[4] == playerTeam) && (BoardArray[8] == playerTeam))
                    || ((BoardArray[6] == playerTeam) && (BoardArray[4] == playerTeam) && (BoardArray[2] == playerTeam))
                    || ((BoardArray[0] == playerTeam) && (BoardArray[3] == playerTeam) && (BoardArray[6] == playerTeam))
                    || ((BoardArray[1] == playerTeam) && (BoardArray[4] == playerTeam) && (BoardArray[7] == playerTeam))
                    || ((BoardArray[2] == playerTeam) && (BoardArray[5] == playerTeam) && (BoardArray[8] == playerTeam))
                    || ((BoardArray[0] == playerTeam) && (BoardArray[1] == playerTeam) && (BoardArray[2] == playerTeam))
                    || ((BoardArray[3] == playerTeam) && (BoardArray[4] == playerTeam) && (BoardArray[5] == playerTeam))
                    || ((BoardArray[6] == playerTeam) && (BoardArray[7] == playerTeam) && (BoardArray[8] == playerTeam)))
                {
                    //Checks which player won.
                    if (playerTeam == 'O')
                    {
                        Console.WriteLine("\n   Player 1 is a Hero, Player 2 is a Zero!");
                        return true;
                    }
                    else
                    {
                        Console.WriteLine("\n   Player 2 Rules, Player 1 Drools!");
                        return true;
                    }
                }
            }
            return false;
        } 

        //Checks for a draw.
        public bool Draw()
        {
            if(turns == 9)
            {
                Console.WriteLine("\n   Draw!\n\n   Press any key to play again.");
                return true;
            }
            return false;
        }
    }
}