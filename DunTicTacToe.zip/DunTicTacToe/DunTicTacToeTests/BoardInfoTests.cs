using NUnit.Framework;
using DunTicTacToe;

namespace DunTicTacToeTests
{
    public class BoardInfoTests
    {
        BoardInfo boardInfo = new BoardInfo();

        [Test]
        public void TeamAssignment1Test()
        {
            int playerTest = 1;
            char testChar = 'X';

            boardInfo.TeamAssignment(playerTest);

            Assert.AreEqual(boardInfo.playerTeam, testChar);
        }

        [Test]
        public void TeamAssignment2Test()
        {
            int playerTest = 2;
            char testChar = 'O';

            boardInfo.TeamAssignment(playerTest);

            Assert.AreEqual(boardInfo.playerTeam, testChar);
        }

        [Test]
        public void SymbolAssignmentTest()
        {
            int inputTest = 7;
            char testChar = 'X';
            boardInfo.playerTeam = 'X';
            
            boardInfo.SymbolAssignment(inputTest);

            Assert.AreEqual(testChar, boardInfo.BoardArray[6]);
        }
    }
}