using NUnit.Framework;
using DunTicTacToe;

namespace DunTicTacToeTests
{
    public class WinCheckerTests
    {
        [Test]
        public void Player1Test()
        {
            int turnsTest = 0;
            char[] TestBoardArray =
            {
                'O', '2', '3', '4', 'O', '6', '7', '8', 'O'
            };

            WinChecker winCheck = new WinChecker(TestBoardArray, turnsTest);

            Assert.IsTrue(winCheck.Win());
        }

        [Test]
        public void Player2Test()
        {
            int turns = 0;
            char[] TestBoardArray =
            {
                'X', '2', '3', 'X', '5', '6', 'X', '8', '9'
            };

            WinChecker winCheck = new WinChecker(TestBoardArray, turns);

            Assert.IsTrue(winCheck.Win());
        }

        [Test]
        public void DrawTest()
        {
            int turns = 9;
            char[] TestBoardArray =
            {
                'X', 'O', 'X', 'O', 'O', 'X', 'X', 'X', 'O'
            };

            WinChecker winCheck = new WinChecker(TestBoardArray, turns);

            Assert.IsTrue(winCheck.Draw());
        }
    }
}